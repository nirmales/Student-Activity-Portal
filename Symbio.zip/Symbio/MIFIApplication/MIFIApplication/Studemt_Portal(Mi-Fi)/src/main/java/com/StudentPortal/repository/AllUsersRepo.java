package com.StudentPortal.repository;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.catalina.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.StudentPortal.entity.AllRecords;
import org.springframework.web.bind.annotation.PathVariable;

@Repository
@Transactional
public interface AllUsersRepo extends JpaRepository<AllRecords,String> {

	public boolean existsByUserName(String userName);
//	@Query("SELECT u FROM User u WHERE u.username  = :email ")
//	User findUserByUsername(@PathVariable String email);

	public AllRecords findByUserName(String userName);

	public List<AllRecords> findAllByUserName(String userName);


	public List<AllRecords> findByUserNameNotIn(List<String> userName);

	public AllRecords findByUserNameAndEmail(String userName, String email);

	public void deleteByUserName(String userName);

//	@Query("SELECT u FROM User u JOIN u.roles r WHERE r.name = :name ")
//	List<User> findByRole(@PathVariable RoleType name);
//}
}
