package com.StudentPortal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.StudentPortal.entity.FeedBack;

public interface FeedbackRepo extends JpaRepository<FeedBack,Integer>{

}
