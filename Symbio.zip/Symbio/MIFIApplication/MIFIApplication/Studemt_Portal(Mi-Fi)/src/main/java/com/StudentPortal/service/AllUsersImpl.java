package com.StudentPortal.service;

import java.security.Principal;
import java.util.List;

import com.StudentPortal.entity.AllRecords;
import com.StudentPortal.entity.FeedBack;
import com.StudentPortal.repository.AllUsersRepo;
import com.StudentPortal.repository.FeedbackRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AllUsersImpl implements AllUsersService{
	@Autowired
	AllUsersRepo aur;
	@Autowired
	FeedbackRepo fbr;
 @Autowired
	private BCryptPasswordEncoder passwordEncode;
	@Override
	public AllRecords addUsers(AllRecords allrecords) {
	 	allrecords.setPassword(passwordEncode.encode(allrecords.getPassword()));
	 	allrecords.setRole("ROLE_USER");
	 	allrecords.setUserProPic("ProfilePic.png");
	 	allrecords.setUserAbout("Welcome To MiFi...!Flaunt your creations Here..");
		return aur.save(allrecords);
	}

	@Override
	public boolean checkUserName(String userName) {
		return aur.existsByUserName(userName);
	}
	
	public void updateUserAbout(String userName, String changeAbout) {
		AllRecords allrecords = aur.findByUserName(userName);
		allrecords.setUserAbout(changeAbout);
		aur.save(allrecords);
	}
	public void updateUserProPic(String userName, String proPic) {
		AllRecords allrecords = aur.findByUserName(userName);
		allrecords.setUserProPic(proPic);
		aur.save(allrecords);
	}

	@Override
	public List<AllRecords> sugUser(String addedUser,Principal p) {
		
		return null;
		
	}

	@Override
	public void feedBack(String userName, String feedback) {
		FeedBack fb=new FeedBack();
		fb.setUserName(userName);
		fb.setUserfb(feedback);
		fbr.save(fb);
		
	}


}
