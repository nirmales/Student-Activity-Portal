package com.StudentPortal.service;
import java.security.Principal;
import java.util.List;

import com.StudentPortal.entity.AllRecords;

public interface AllUsersService {

	public AllRecords addUsers(AllRecords allrecords);
	
	public boolean checkUserName(String userName);
	
	public void updateUserAbout(String userName, String changeAbout);
	
	public void updateUserProPic(String userName, String proPic);
	public List<AllRecords> sugUser(String addedUser,Principal p);
	public void feedBack(String userName,String feedback);
	 
}
