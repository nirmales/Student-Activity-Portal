package com.StudentPortal.service;

import com.StudentPortal.repository.UserBuddiesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StudentPortal.entity.UserBuddies;

@Service
public class UserBuddyServiceImpl implements UserBuddyService {
	@Autowired
	UserBuddiesRepo ubr;
	public void addBuddy(String buddyUserName,String userName) {
		UserBuddies ub=new UserBuddies();
		ub.setBuddyUserName(buddyUserName);
		ub.setUserName(userName);
		ubr.save(ub);
		
	}
}
