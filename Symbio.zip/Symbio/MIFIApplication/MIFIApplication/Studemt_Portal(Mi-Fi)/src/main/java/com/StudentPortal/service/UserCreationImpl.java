package com.StudentPortal.service;

import java.time.LocalDate;

import com.StudentPortal.repository.AllUsersRepo;
import com.StudentPortal.repository.UserCreationsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.StudentPortal.entity.AllRecords;
import com.StudentPortal.entity.UserCreations;

@Service
public class UserCreationImpl implements UserCreationService {
    @Autowired
	AllUsersRepo aur;
    @Autowired
	UserCreationsRepo ucr;
	
	@Override
	public UserCreations addCreation(String userName, String creationCaption,String creationName) {
		   UserCreations uc =new UserCreations();
		   AllRecords ar= new AllRecords();
		   ar=aur.findByUserName(userName);
		   uc.setFirstName(ar.getFirstName());
		   uc.setLastName(ar.getLastName());
		   uc.setProPic(ar.getUserProPic());
		   uc.setCaption(creationCaption);
		   uc.setCreation(creationName);
		   uc.setUserName(userName);
		   uc.setCreationDate(LocalDate.now());
		   return ucr.save(uc);
	}
	

}
