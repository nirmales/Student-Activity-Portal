package com.StudentPortal.service;

import com.StudentPortal.entity.UserCreations;
public interface UserCreationService {

	public UserCreations addCreation(String userName, String creationCaption,String creationName);
}
